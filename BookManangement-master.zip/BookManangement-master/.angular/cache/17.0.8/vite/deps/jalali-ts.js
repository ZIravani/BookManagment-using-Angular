import {
  require_dist
} from "./chunk-5LQQ2OLG.js";
import "./chunk-STUZPFMT.js";
export default require_dist();
//# sourceMappingURL=jalali-ts.js.map
