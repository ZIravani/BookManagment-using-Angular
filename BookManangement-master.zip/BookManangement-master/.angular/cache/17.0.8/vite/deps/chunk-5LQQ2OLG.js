import {
  __commonJS
} from "./chunk-STUZPFMT.js";

// node_modules/jalali-ts/dist/index.js
var require_dist = __commonJS({
  "node_modules/jalali-ts/dist/index.js"(exports, module) {
    var j = Object.defineProperty;
    var O = Object.getOwnPropertyDescriptor;
    var Z = Object.getOwnPropertyNames;
    var L = Object.prototype.hasOwnProperty;
    var N = (a, e) => {
      for (var t in e)
        j(a, t, { get: e[t], enumerable: true });
    };
    var F = (a, e, t, n) => {
      if (e && typeof e == "object" || typeof e == "function")
        for (let r of Z(e))
          !L.call(a, r) && r !== t && j(a, r, { get: () => e[r], enumerable: !(n = O(e, r)) || n.enumerable });
      return a;
    };
    var z = (a) => F(j({}, "__esModule", { value: true }), a);
    var G = {};
    N(G, { Jalali: () => p, Utils: () => m });
    module.exports = z(G);
    var m = class {
      static toJalali(e, t, n) {
        let r = e instanceof Date ? e : null, s = r ? r.getFullYear() : e, i = r ? r.getMonth() + 1 : t, o = r ? r.getDate() : n, u = this.gregorianToJulian(s, i, o);
        return this.julianToJalali(u);
      }
      static toGregorian(e, t, n) {
        let r = this.jalaliToJulian(e, t, n);
        return this.julianToGregorian(r);
      }
      static isValid(e, t, n, r = 0, s = 0, i = 0, o = 0) {
        return e >= -61 && e <= 3177 && t >= 1 && t <= 12 && n >= 1 && n <= this.monthLength(e, t) && r >= 0 && r <= 23 && s >= 0 || s <= 59 && i >= 0 || i <= 59 && o >= 0 || o <= 999;
      }
      static isLeapYear(e) {
        return this.calculateLeap(e) === 0;
      }
      static monthLength(e, t) {
        return t <= 6 ? 31 : t <= 11 || this.isLeapYear(e) ? 30 : 29;
      }
      static calculateLeap(e, t) {
        let n = this.breaks.length, r = t ? t.jp : this.breaks[0], s = t ? t.jump : 0;
        if (!t) {
          if (e < r || e >= this.breaks[n - 1])
            throw new Error(`Invalid Jalali year ${e}`);
          for (let u = 1; u < n; u++) {
            let c = this.breaks[u];
            if (s = c - r, e < c)
              break;
            r = c;
          }
        }
        let i = e - r;
        s - i < 6 && (i = i - s + this.div(s + 4, 33) * 33);
        let o = this.mod(this.mod(i + 1, 33) - 1, 4);
        return o === -1 && (o = 4), o;
      }
      static calculateJalali(e, t = true) {
        let n = this.breaks.length, r = e + 621, s = -14, i = this.breaks[0];
        if (e < i || e >= this.breaks[n - 1])
          throw new Error(`Invalid Jalali year ${e}`);
        let o = 0;
        for (let d = 1; d < n; d++) {
          let g = this.breaks[d];
          if (o = g - i, e < g)
            break;
          s = s + this.div(o, 33) * 8 + this.div(this.mod(o, 33), 4), i = g;
        }
        let u = e - i;
        s = s + this.div(u, 33) * 8 + this.div(this.mod(u, 33) + 3, 4), this.mod(o, 33) === 4 && o - u === 4 && (s += 1);
        let c = this.div(r, 4) - this.div((this.div(r, 100) + 1) * 3, 4) - 150, l = 20 + s - c;
        return { gregorianYear: r, march: l, leap: t ? this.calculateLeap(e, { jp: i, jump: o }) : -1 };
      }
      static jalaliToJulian(e, t, n) {
        let r = this.calculateJalali(e, false);
        return this.gregorianToJulian(r.gregorianYear, 3, r.march) + (t - 1) * 31 - this.div(t, 7) * (t - 7) + n - 1;
      }
      static julianToJalali(e) {
        let t = this.julianToGregorian(e), n = t.year - 621, r = this.calculateJalali(n), s = this.gregorianToJulian(t.year, 3, r.march), i = e - s;
        if (i >= 0) {
          if (i <= 185)
            return { year: n, month: 1 + this.div(i, 31), date: this.mod(i, 31) + 1 };
          i -= 186;
        } else
          n -= 1, i += 179, r.leap === 1 && (i += 1);
        return { year: n, month: 7 + this.div(i, 30), date: this.mod(i, 30) + 1 };
      }
      static gregorianToJulian(e, t, n) {
        return this.div((e + this.div(t - 8, 6) + 100100) * 1461, 4) + this.div(153 * this.mod(t + 9, 12) + 2, 5) + n - 34840408 - this.div(this.div(e + 100100 + this.div(t - 8, 6), 100) * 3, 4) + 752;
      }
      static julianToGregorian(e) {
        let t = 4 * e + 139361631;
        t = t + this.div(this.div(4 * e + 183187720, 146097) * 3, 4) * 4 - 3908;
        let n = this.div(this.mod(t, 1461), 4) * 5 + 308, r = this.div(this.mod(n, 153), 5) + 1, s = this.mod(this.div(n, 153), 12) + 1;
        return { year: this.div(t, 1461) - 100100 + this.div(8 - s, 6), month: s, date: r };
      }
      static jalaliWeek(e, t, n) {
        let r = this.toDate(e, t, n).getDay(), s = r === 6 ? 0 : -(r + 1), i = 6 + s;
        return { saturday: this.julianToJalali(this.jalaliToJulian(e, t, n + s)), friday: this.julianToJalali(this.jalaliToJulian(e, t, n + i)) };
      }
      static toDate(e, t, n, r = 0, s = 0, i = 0, o = 0) {
        let u = this.toGregorian(e, t, n);
        return new Date(u.year, u.month - 1, u.date, r, s, i, o);
      }
      static div(e, t) {
        return ~~(e / t);
      }
      static mod(e, t) {
        return e - ~~(e / t) * t;
      }
    };
    m.breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
    var T = ["یکشنبه", "دوشنبه", "سه شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
    var v = ["ی", "د", "س", "چ", "پ", "ج", "ش"];
    var I = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];
    var b = (a) => {
      let e = m.toJalali(a);
      return e.month -= 1, e;
    };
    var y = (a, e, t) => {
      let n = m.toGregorian(a, e + 1, t);
      return n.month -= 1, n;
    };
    var Y = (a, e) => (e = m.mod(e, 12), a += m.div(e, 12), e < 0 && (e += 12, a -= 1), m.monthLength(a, e + 1));
    var w = (a) => {
      let e = /* @__PURE__ */ new Map();
      return e.set("۰", "0"), e.set("۱", "1"), e.set("۲", "2"), e.set("۳", "3"), e.set("۴", "4"), e.set("۵", "5"), e.set("۶", "6"), e.set("۷", "7"), e.set("۸", "8"), e.set("۹", "9"), String(a).split("").map((t) => e.get(t) ?? t).join("");
    };
    var S = (a, e) => {
      let t = null;
      return String(a).toLowerCase().includes("am") && (t = "am"), String(a).toLowerCase().includes("pm") && (t = "pm"), t === "am" && e === 12 ? 0 : t === "pm" && e >= 1 && e <= 11 ? e + 12 : t !== null && e > 12 ? -1 : e;
    };
    var H = (a) => a.length === 1 ? Number(a) * 100 : a.length === 2 ? Number(a) * 10 : a.length > 3 ? -1 : Number(a);
    var f = (a, e = 2) => String(a).padStart(e, "0");
    var k = (a) => {
      throw new Error(`Invalid: ${a}`);
    };
    var h = class {
      constructor(e = /* @__PURE__ */ new Date(), t = true) {
        this.date = e;
        if (h.checkTimeZone) {
          let n = h.timeZone, r = Intl.DateTimeFormat().resolvedOptions().timeZone;
          r !== n && (console.warn(`Your system time zone doesn't equal to '${n}', current: ${r}`), console.warn("You may getting unexpected results (calculated timestamp)"));
        }
        t || this.date.setMilliseconds(0);
      }
      static set timeZone(e) {
        this._timeZone = e, this.setTimeZone && typeof process == "object" && process?.release?.name === "node" && (process.env.TZ = e);
      }
      static get timeZone() {
        return this._timeZone ?? this.defaultTimeZone;
      }
      static parse(e, t = true) {
        let n = w(e), r = n.match(/\d\d?\d?\d?/g) || [], s = new Array(7).fill("0"), [i, o, u, c, l, d, g] = [...r, ...s].slice(0, 7).map((D, M) => {
          let J = Number(D);
          return M === 3 ? J = S(n, Number(D)) : M === 6 && (J = H(D)), J;
        });
        return m.isValid(i, o, u, c, l, d, g) || k(e), new h(m.toDate(i, o, u, c, l, d, g), t);
      }
      static gregorian(e, t = true) {
        let n = w(e), r = new Date(n);
        return Number.isNaN(+r) && k(e), new h(r, t);
      }
      static timestamp(e, t = true) {
        return new h(new Date(e), t);
      }
      static now(e = true) {
        return new h(/* @__PURE__ */ new Date(), e);
      }
      clone(e = true) {
        return h.timestamp(+this, e);
      }
      valueOf() {
        return +this.date;
      }
      toString() {
        return this.format();
      }
      getFullYear() {
        return b(this.date).year;
      }
      getMonth() {
        return b(this.date).month;
      }
      getDate() {
        return b(this.date).date;
      }
      getHours() {
        return this.date.getHours();
      }
      getMinutes() {
        return this.date.getMinutes();
      }
      getSeconds() {
        return this.date.getSeconds();
      }
      getMilliseconds() {
        return this.date.getMilliseconds();
      }
      setFullYear(e) {
        let t = b(this.date), n = Math.min(t.date, Y(e, t.month)), r = y(e, t.month, n);
        return this.update(r), this;
      }
      setMonth(e) {
        let t = b(this.date), n = Math.min(t.date, Y(t.year, e));
        this.setFullYear(t.year + m.div(e, 12)), e = m.mod(e, 12), e < 0 && (e += 12, this.add(-1, "year"));
        let r = y(this.getFullYear(), e, n);
        return this.update(r), this;
      }
      setDate(e) {
        let t = b(this.date), n = y(t.year, t.month, e);
        return this.update(n), this;
      }
      setHours(e) {
        return this.date.setHours(e), this;
      }
      setMinutes(e) {
        return this.date.setMinutes(e), this;
      }
      setSeconds(e) {
        return this.date.setSeconds(e), this;
      }
      setMilliseconds(e) {
        return this.date.setMilliseconds(e), this;
      }
      isLeapYear() {
        return m.isLeapYear(b(this.date).year);
      }
      monthLength() {
        let e = b(this.date);
        return Y(e.year, e.month);
      }
      add(e, t) {
        switch (t) {
          case "year":
            this.setFullYear(this.getFullYear() + e);
            break;
          case "month":
            this.setMonth(this.getMonth() + e);
            break;
          case "week":
            this.date.setDate(this.date.getDate() + e * 7);
            break;
          case "day":
            this.date.setDate(this.date.getDate() + e);
            break;
        }
        return this;
      }
      startOf(e) {
        if (e === "year" && this.setMonth(0), (e === "year" || e === "month") && this.setDate(1), e === "week") {
          let t = this.date.getDay(), n = this.date.getDate() - (t === 6 ? 0 : this.date.getDay() + 1);
          this.date.setDate(n);
        }
        return this.setHours(0).setMinutes(0).setSeconds(0).setMilliseconds(0), this;
      }
      endOf(e) {
        return this.startOf(e).add(1, e).setMilliseconds(-1), this;
      }
      dayOfYear(e) {
        let t = this.clone(), n = +t.startOf("day"), r = +t.startOf("year"), s = Math.round((n - r) / 864e5) + 1;
        return e === void 0 ? s : (this.add(e - s, "day"), this);
      }
      format(e = "YYYY/MM/DD HH:mm:ss", t = false) {
        let n = String(e), r = t ? this.date : this, s = r.getMonth(), i = this.date.getDay(), o = r.getFullYear(), u = s + 1, c = r.getDate(), l = r.getHours(), d = r.getMinutes(), g = r.getSeconds(), D = r.getMilliseconds();
        if (t || (e.includes("dddd") && (n = n.replace("dddd", T[i])), e.includes("dd") && (n = n.replace("dd", v[i])), e.includes("MMMM") && (n = n.replace("MMMM", I[s]))), e.includes("YYYY") && (n = n.replace("YYYY", String(o))), e.includes("MM") && (n = n.replace("MM", f(u))), e.includes("DD") && (n = n.replace("DD", f(c))), e.includes("HH") && (n = n.replace("HH", f(l))), e.includes("mm") && (n = n.replace("mm", f(d))), e.includes("ss") && (n = n.replace("ss", f(g))), e.includes("SSS") && (n = n.replace("SSS", f(D, 3))), e.includes("hh")) {
          let M = l >= 12 ? "pm" : "am";
          e.includes("a") && (n = n.replace("a", M)), e.includes("A") && (n = n.replace("A", M.toUpperCase())), l === 0 && (l = 12), l >= 13 && l <= 23 && (l -= 12), n = n.replace("hh", f(l));
        }
        return n;
      }
      gregorian(e = "YYYY-MM-DD HH:mm:ss") {
        return this.format(e, true);
      }
      update(e) {
        this.date = new Date(e.year, e.month, e.date, this.getHours(), this.getMinutes(), this.getSeconds(), this.getMilliseconds());
      }
    };
    var p = h;
    p.defaultTimeZone = "Asia/Tehran", p.checkTimeZone = true, p.setTimeZone = true;
  }
});

export {
  require_dist
};
//# sourceMappingURL=chunk-5LQQ2OLG.js.map
