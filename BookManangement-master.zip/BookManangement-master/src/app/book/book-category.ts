export type BookCategory = {
    id: number,
    title: string
}