import { Component } from '@angular/core';

@Component({
  selector: 'app-not-found404',
  standalone: true,
  imports: [],
  templateUrl: './not-found404.component.html'
})
export class NotFound404Component {

}
