export var HotkeysAllowedIn = ['INPUT', 'TEXTAREA', 'SELECT'];

export const ctrlUp = 'ctrl+up';
export const ctrlDown = 'ctrl+down';
export const ctrlLeft = 'ctrl+left';
export const ctrlRight = 'ctrl+right';
export const ctrlI = 'ctrl+i';
export const ctrlEnter = 'ctrl+enter';
export const ctrlP = 'ctrl+p';
export const ctrlE = 'ctrl+e';
export const ctrlQ = 'ctrl+q';
export const ctrlB = 'ctrl+b';
export const ctrlS = 'ctrl+s';
export const ctrlC = 'ctrl+c';
export const ctrlV = 'ctrl+v';
export const down = 'down';
export const up = 'up';
export const enter = 'enter';
