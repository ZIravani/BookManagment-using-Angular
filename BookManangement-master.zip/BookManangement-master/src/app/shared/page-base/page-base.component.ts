import { Component, Inject } from '@angular/core';

@Component({
  selector: 'app-page-base',
  standalone: true,
  imports: [],
  templateUrl: './page-base.component.html'
})
export class PageBaseComponent {

  clasificationLevel

  constructor(@Inject(String) pageId) {
  }

  getClasificationLevel() {
    // api level
  }
}
